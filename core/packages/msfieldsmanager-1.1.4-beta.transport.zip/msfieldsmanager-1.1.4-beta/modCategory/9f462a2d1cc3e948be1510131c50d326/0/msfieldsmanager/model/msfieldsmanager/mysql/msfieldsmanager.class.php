<?php
require_once (dirname(dirname(__FILE__)) . '/msfieldsmanager.class.php');
class MsFieldsManager_mysql extends MsFieldsManager {}