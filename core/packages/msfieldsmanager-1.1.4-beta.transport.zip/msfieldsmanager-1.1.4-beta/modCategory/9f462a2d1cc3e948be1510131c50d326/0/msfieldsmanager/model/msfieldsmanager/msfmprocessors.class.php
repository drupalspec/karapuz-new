<?php
class MsfmProcessors extends xPDOSimpleObject {}