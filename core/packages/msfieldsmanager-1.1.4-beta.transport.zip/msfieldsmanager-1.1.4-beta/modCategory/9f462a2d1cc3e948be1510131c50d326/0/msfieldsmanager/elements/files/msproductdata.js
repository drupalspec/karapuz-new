miniShop2.plugin.msfieldsmanager = {
    getFields: function(config) {
        return {}
    }
    ,getColumns: function() {
        return {}
    }
};