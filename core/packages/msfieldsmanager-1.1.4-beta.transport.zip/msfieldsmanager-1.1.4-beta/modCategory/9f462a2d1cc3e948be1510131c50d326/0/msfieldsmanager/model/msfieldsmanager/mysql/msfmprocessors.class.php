<?php
require_once (dirname(dirname(__FILE__)) . '/msfmprocessors.class.php');
class MsfmProcessors_mysql extends MsfmProcessors {}