<?php
class Msfm%name%GetListProcessor extends modObjectGetListProcessor {
    public $classKey = '%classKey%';
    public $defaultSortField = '%sort%';
    public $defaultSortDirection = 'ASC';
    public $checkListPermission = true;
}
return 'Msfm%name%GetListProcessor';