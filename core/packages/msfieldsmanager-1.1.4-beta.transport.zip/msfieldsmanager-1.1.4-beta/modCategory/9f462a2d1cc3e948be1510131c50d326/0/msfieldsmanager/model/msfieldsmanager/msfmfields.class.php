<?php
class MsfmFields extends xPDOSimpleObject {}