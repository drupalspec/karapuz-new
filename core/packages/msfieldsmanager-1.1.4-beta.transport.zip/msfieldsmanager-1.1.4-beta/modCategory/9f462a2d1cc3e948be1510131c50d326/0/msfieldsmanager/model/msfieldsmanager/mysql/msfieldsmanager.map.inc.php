<?php
$xpdo_meta_map['MsFieldsManager']= array (
  'package' => 'msfieldsmanager',
  'version' => '1.1',
  'extends' => 'msProductData',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
