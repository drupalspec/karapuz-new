<?php
/**
 * Default Russian Lexicon Entries for msFieldsManager
 *
 * @package msfieldsmanager
 * @subpackage lexicon
 */
$_lang['msfieldsmanager'] = 'msFieldsManager';
$_lang['msfieldsmanager.cmenu.msfmfields'] = 'msFieldsManager';
$_lang['msfieldsmanager.cmenu.msfmfields_desc'] = '';