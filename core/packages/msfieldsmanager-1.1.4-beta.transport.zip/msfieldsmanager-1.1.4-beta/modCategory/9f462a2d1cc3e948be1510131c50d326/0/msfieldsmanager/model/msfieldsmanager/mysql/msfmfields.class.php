<?php
require_once (dirname(dirname(__FILE__)) . '/msfmfields.class.php');
class MsfmFields_mysql extends MsfmFields {}