<?php
/**
 * Default English Lexicon Entries for msFieldsManager
 *
 * @package msfieldsmanager
 * @subpackage lexicon
 */
$_lang['msfieldsmanager'] = 'msFieldsManager';
$_lang['msfieldsmanager.cmenu.msfieldsmanager'] = 'msFieldsManager';
$_lang['msfieldsmanager.cmenu.msfieldsmanager_desc'] = '';
$_lang['msfieldsmanager.cmenu.msfmfields'] = 'msFieldsManager';
$_lang['msfieldsmanager.cmenu.msfmfields_desc'] = '';