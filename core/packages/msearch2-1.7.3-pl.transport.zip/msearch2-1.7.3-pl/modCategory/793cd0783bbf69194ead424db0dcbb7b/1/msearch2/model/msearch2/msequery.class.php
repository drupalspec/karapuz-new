<?php
class mseQuery extends xPDOObject {}