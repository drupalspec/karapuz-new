<?php
class mseWord extends xPDOObject {}